<?php

	class Request{
		
		public $method;

		public $header;
		
		public $urlparams;

		public $payload;

	}
	
?>