<?php

    class clients{

        function getData($ID, $filter){

            $responsepayload = 'response data with id: '.$ID.' and filter: '.$filter;

            return $responsepayload;

        }

    }
  
?>