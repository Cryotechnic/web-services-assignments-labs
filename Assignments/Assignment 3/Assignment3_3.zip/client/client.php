<?php
	// include guzzle client
	require_once 'C:/xampp/htdocs/vendor/autoload.php';
	
	// create a new cURL resource
	// $ch = curl_init();
	
	// set URL and other appropriate options

	// Assuming we want the information of a certain client e.g., client with id 123
	// What should be the format of the URL when requesting that information through api/index.php?

	// We wnat to use the URL format: .../api/clients/123?filter=value

	// and rewrite it to the format: .../api/index.php?clients=123&filter=value

	// instead of what you have in your MVC, with the htaccess: .../api/index.php?url=clients/123&filter=value

	// thus, we use the rewrite rule: RewriteRule ^/?([a-z]+)/(.*)$ index.php?$1=$2 [QSA,L]

	// curl_setopt($ch, CURLOPT_URL, "http://localhost/webservice/api/clients/123?filter=value");

	// Implement Guzzle HTTP Client with request headers
	$client = new GuzzleHttp\Client([
		'base_uri' => 'http://localhost/webservice/api/clients/',
		'timeout'  => 2.0,
		'curl' => [
			CURLOPT_HTTPHEADER => [
				'Accept' => 'application/json',
			],
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_RETURNTRANSFER => true,
		]
	]);

	// Send Guzzle HTTP Client request

	$request = new GuzzleHttp\Psr7\Request('GET', '123?conversion=success');
	$response = $client->send($request);
	echo $response->getBody();

	// Guzzle HTTP Client POST request
	$request2 = new GuzzleHttp\Psr7\Request('POST', '123?conversion=success');
	$response2 = $client->send($request2);
	echo $response2->getBody();
	
	// Later our target is to make the URL canonical of the format: http://localhost/webservice/api/clients/123?fields=name

	// Also set the Accept header to tell the web service our desired response payload format e.g., application/json


	// $requestheaders = ['accept: application/json'];


	// curl_setopt($ch, CURLOPT_HTTPHEADER, $requestheaders);
	
	// In case of a Redirect, follow the Location: page.php automatically:
	//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

	// 3- instead of  outputing the data directly to the browser, capture it in a variable
	// curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
	// grab URL and pass it to the browser
	// Get the payload of the response:
	// $responsedata = curl_exec($ch);
	
	// echo $responsedata;

	// close cURL resource, and free up system resources
	// curl_close($ch);

?>