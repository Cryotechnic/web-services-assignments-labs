<?php
	echo "<script src='https://code.jquery.com/jquery-3.5.1.min.js'></script>";
	echo "<script>
	$(document).ready(function(){
		$.get('http://localhost/webservice/api/clients/id'" . $_GET['id'] . "', function(data, status){
			console.log(data);
			console.log(status);
		});
	});
	</script>";
?>